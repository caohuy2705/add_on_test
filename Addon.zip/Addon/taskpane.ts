// taskpane.ts
Office.onReady((info) => {
    if (info.host === Office.HostType.Word) {
      document.getElementById('insertTextButton').onclick = insertTextIntoDocument;
    }
  });
  
  async function insertTextIntoDocument() {
    await Word.run(async (context) => {
      const body = context.document.body;
  
      // Insert a paragraph with the predefined text
      const paragraph = body.insertParagraph('Hello, Word Add-in!', Word.InsertLocation.end);
  
      // Set the style of the inserted paragraph
      paragraph.style = 'Heading1';
  
      await context.sync();
    });
  }